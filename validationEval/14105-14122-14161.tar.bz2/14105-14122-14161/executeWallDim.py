#!/usr/bin/python

import wallDimCheck

def main():
  wallDimCheck.fnWallDimCheck('ct1','w01','w02','w03','w04','w05','w06')
  wallDimCheck.fnWallDimCheck('ct1','w05','w06','w01','w02','w03','w04')
main()
