insert into objects values('nc1'),('nc2'),('nc3'),('nc4'),('nc5'),('c1'),('c2'),('c3'),('c4'),('c5');

insert into abstractDoor values('d1',200,100,55,60,100),('d2',200,100,55,60,100),('d3',200,100,55,60,100),('d4',200,100,55,60,100),('d5',60,54,10,10,100);

insert into types values('nct1','beam','concrete beam'),('nct2','bench','wooden'),('nct3','switch',''),('nct4','amplifier',''),('nct5','stage','concrete stage'),('ct1','ampBox',''),('ct2','classRoom',''),('ct3','chalkBox','');

insert into containerConcreteTypes values('ct1',500,600,760,10,''),('ct2',6100,13600,3180,280,''),('ct3',100,100,100,1,'');

insert into nonContainerConcreteTypes values('nct1',6100,570,260,''),('nct2',40,250,300,''),('nct3',250,100,350,'');

insert into propertyTypes values('pT1','boolean'),('pT2','number'),('pT3','string'),('pT4','date');

insert into properties values('pr1','fragile','pT1',''),('pr2','weight','pT2',''),('pr3','temp','pT2',''),('pr4','side UP','pT3',''),('pr5','expiry','pT4','');

insert into abstractWall values('w01',6100,3180,250,250,250),('w02',6100,13600,250,250,250),('w03',13600,3180,250,250,250),('w04',13600,3180,250,250,250),('w05',6100,570,250,250,250),('w06',6100,260,250,140,250),('w07',500,760,211,211,211),('w08',500,760,211,211,211),('w09',600,760,211,211,211),('w10',500,600,211,211,211),('w11',600,760,211,211,211),('w12',500,600,211,211,211),('w13',6100,570,255,250,205),('w14',6100,570,255,250,205),('w15',260,570,255,250,205),('w16',6100,260,255,250,205),('w17',260,570,255,250,205),('w18',6100,260,255,250,205),('w19',900,750,218,165,35),('w20',750,750,218,165,35),('w21',900,750,218,165,35),('w22',900,750,218,165,35),('w23',750,750,218,165,35),('w24',75,750,218,165,35);


insert into unitList values('u01','degree-celcius','','pr3'),('u02','kilogram','','pr2'),('u03','sideId','','pr4'),('u04','date','','pr5'),('u05','percent','','pr1');

insert into WallDoor values('w01','d1',25,30,'BCDA'),('w02','d2',15,30,'CDAB'),('w03','d3',40,20,'ADCB'),('w04','d4',30,25,'BADC'),('w05','d5',25,30,'BCDA');

insert into containerObjects values('c1','ct1','ampBox',''),('c2','ct2','classRoom','');

insert into nonContainerObjects values('nc1','nct1','beam',''),('nc2','nct2','bench','');

insert into containerObjectProperties values('c1','UID01','pr1',50,'','amp boxP'),('c2','UID02','pr4',30,'','roomP');

insert into nonContainerObjectProperties values('nc1','UID03','pr2',100,'','beamP'),('nc2','UID04','pr3',40,'','benchP');

insert into containerConcreteTypeFaces values('ct2','w01','w02','w03','w04','w05','w06'),('ct1','w07','w08','w09','w10','w11','w12');

insert into nonContainerConcreteTypeFaces values('nct1','w13','w14','w15','w16','w17','w18'),('nct2','w19','w20','w21','w22','w23','w24');

insert into containerConcreteTypeProperties values('ct1','pr2',50,'u02',''),('ct2','pr3',20,'u01','');

insert into nonContainerConcreteTypeProperties values('nct1','pr1',50,'u05',''),('nct2','pr4',20,'u03','');

insert into directChild_parent values('nc1','c1',1,8020,1),('c1','c2',61000,650,1500);

