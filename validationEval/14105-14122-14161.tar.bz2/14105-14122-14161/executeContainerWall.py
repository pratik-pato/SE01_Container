#!/usr/bin/python

import validateContainerFaces

def main():
  validateContainerFaces.fnInsertFaces('ct3','w01','w02','w05','w30','w20','w18') 
  validateContainerFaces.fnInsertFaces('ct5','w37','w38','w39','w40','w41','w42') 
  validateContainerFaces.fnInsertFaces('ct3','w01','w02','w05','w30','w20','w18')
  validateContainerFaces.fnInsertFaces('ct1','w13','w14','w15','w16','w17','w01')
main()
