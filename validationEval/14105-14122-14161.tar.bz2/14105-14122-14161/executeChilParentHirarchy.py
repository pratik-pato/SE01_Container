#!/usr/bin/python

import validateChildParentHirerchy

def main():
  validateChildParentHirerchy.fnInsertDirectChild_Parent('c3','c1',10,10,10,'ABCD','ABCD')
  validateChildParentHirerchy.fnInsertDirectChild_Parent('nc8','c2',10,10,10,'ABCD','ABCD')
main()
