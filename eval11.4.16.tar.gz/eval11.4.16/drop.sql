drop table containerObjectProperties CASCADE;
drop table nonContainerObjectProperties CASCADE;
drop table containerConcreteTypeProperties CASCADE;
drop table nonContainerConcreteTypeProperties CASCADE;
drop table directChild_parent CASCADE;
drop table nonContainerObjects CASCADE;
drop table containerObjects CASCADE;
drop table unitList CASCADE;
drop table properties CASCADE;
drop table containerConcreteTypeFaces CASCADE; 
drop table containerConcreteTypes CASCADE;
drop table nonContainerConcreteTypeFaces CASCADE; 
drop table nonContainerConcreteTypes CASCADE;
drop table types CASCADE;
drop table objects CASCADE;
drop table propertyTypes CASCADE;
drop table WallDoor CASCADE;
drop table abstractWall CASCADE;
drop table abstractDoor CASCADE;


